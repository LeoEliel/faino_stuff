const prova1 = document.querySelector("#prova1")
const prova2 = document.querySelector("#prova2")
const result = document.querySelector("#result");
const checkbox = document.querySelector('input[value="mediaa"]');



form.addEventListener("submit", (e) => 
    {

        if (checkbox.checked) {
            let data = (prova1+prova2)/2;
                   
        }else{

        }

    }
);

